import React from 'react'; 
const HomeComponent = ()=> {

    return (
        <div>
            <h2>Home Component </h2>
        </div>
    )
}

export default HomeComponent;
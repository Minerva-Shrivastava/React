import React from 'react'; 
const AboutComponent = ()=> {

    return (
        <div>
            <h2>About Component </h2>
        </div>
    )
}

export default AboutComponent;
import React from 'react'; 
import { NavLink } from 'react-router-dom';

const NavigationLinksComponent = ()=> {

    return (
        <div className="list-group">
            <NavLink exact to="/" activeClassName="selected">Home</NavLink>
            <NavLink to="/about" activeClassName="selected">About</NavLink>
            <NavLink to="/content" activeClassName="selected">Content</NavLink>
        </div>
    )
}

export default NavigationLinksComponent;
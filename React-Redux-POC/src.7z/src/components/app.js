import React from 'react';
import UserList from '../containers/user-list';
import UserDetail from '../containers/user-detail';
const App = () =>{
    return(
        <div>
            <h1>React-Redux-UL-POC</h1>
            <hr/>
            {/* User List Component */}
            <UserList/>
            <hr/>
            {/* User Detail Component */}
            <UserDetail/>
        </div>
    )
}
export default App;
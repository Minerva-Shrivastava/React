export default function(){
    
    return [
        {
            id:1,
            name: 'Minerva Shrivastava',
            contact: '7861326544',
            email: 'minerva.shrivastava@gmail.com'
        },
        {
            id:2,
            name: 'Mansi Shrivastava',
            contact: '8861326544',
            email: 'mansi.shrivastava@gmail.com'
        }
    ]
}
import React,{ Component } from 'react';
import {connect} from 'react-redux';

class UserDetail extends Component {
    
    render() {
        // If user is null, show a msg 
        if(!this.props.user){
            return <h3>Select User ...</h3>
        }
        return(
            //User which we recieved through connection
            <div>
                <p>ID : {this.props.user.id}</p> 
                <p>Name : {this.props.user.name}</p> 
                <p>Contact : {this.props.user.contact}</p> 
                <p>Email : {this.props.user.email}</p> 
            </div>
        )
    }
}

function mapStateToProps(state){
    return{
        user:state.activeUser //The name you gave in reducer
    }
}
export default connect(mapStateToProps) (UserDetail);
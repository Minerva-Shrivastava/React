import React from 'react';

class TodoTextComponent extends React.Component {

    constructor(props){
        super(props);
        this.toggleIsEditing = this.toggleIsEditing.bind(this);
        this.updateTodo = this.updateTodo.bind(this);
        this.state={
            isEditing : false
        }
    }

    updateTodo(event){
        event.preventDefault();
        // Pass the position and value in edit todo method
        //console.log("----------update Todo method-----------"+this.input.value);
        this.props.editTodo(this.props.index, this.input.value);
        this.toggleIsEditing();
    }

    

    toggleIsEditing(){
        this.setState({
            isEditing: !this.state.isEditing 
        })
    }

    renderUpdateForm(){
        return(
            <form onSubmit={this.updateTodo}>
                <input type="text" 
                    defaultValue = {this.props.todo.todoText}
                    ref = {(value)=>{this.input = value;}}/>
                <button type="submit">Update</button>

            </form>    
        )
        
    }

    renderTodoText(){
        return(
            <li onClick={()=>{this.props.clickHandler(this.props.index)}}
            className={this.props.todo.compleated===true?'compleated':''}>
            {this.props.todo.todoText}
    
            <button id="deleteButton" onClick={(event)=>{
                event.stopPropagation();
                this.props.deleteTodo(this.props.index)}}>
                X
            </button>
    
            <button id="editButton" onClick={(event)=>{
                event.stopPropagation();
                this.toggleIsEditing()}}>
                Edit
            </button>
            </li>    
        )
        
    }

    render(){
        const {isEditing} = this.state;
        return(
            <section>
                { isEditing ? this.renderUpdateForm() : this.renderTodoText()}
            </section>            
        );
    }
}
 export default TodoTextComponent;
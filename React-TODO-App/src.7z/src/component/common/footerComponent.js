import React, { Component } from 'react';

const FooterComponent = props =>{

    return(<h4>Created By : Minerva Shrivastava</h4>);

}

export default FooterComponent; 
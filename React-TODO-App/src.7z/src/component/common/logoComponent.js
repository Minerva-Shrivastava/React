import React from 'react';
const LogoComponent = function(props){
    return(
        <h2>React-{props.logo}</h2>
    );
} 
export default LogoComponent;
import React from 'react';
import TodoTextComponent from './todoTextComponent';
import TodoFormComponent from './todoFormComponent';
import PropTypes from 'prop-types'; 
class TodoListComponent extends React.Component {
    
    constructor(props){
        super(props);
        this.changeTodo = this.changeTodo.bind(this);
        this.updateTodo = this.updateTodo.bind(this);
        this.addTodo = this.addTodo.bind(this);
        this.deleteTodo = this.deleteTodo.bind(this);
        this.editTodo = this.editTodo.bind(this);
        this.state = {
            todos:[
                {todoText:'Create React-TODO App', compleated:false},
                {todoText:'Create PPT for React', compleated:false},
                {todoText:'REDUX POC', compleated:false}
            ],
            currentTodo:'',
           // totalTodoVsCompleatedTodosCount:{totalTodos:0, compleatedTodos:0}
        };
    }

    changeTodo(index) {
        //1.get all the todos in the local variable.
        //2.get the clicked todo 
        //3.change the compleated status of the clicked todo 
        let todos = this.state.todos;
        let todo = todos[index];
        todo.compleated = !todo.compleated;
        // if(todo.compleated===true){
        //     this.incrementCompletedTodoCount();
        // }
        this.setState({
            todos
        });
        console.log(this.state.todos[index]);
    }

    updateTodo(event){

        this.setState({
            currentTodo:event.target.value
        })
    }

    addTodo(event){
        event.preventDefault();
        let todos = this.state.todos;
        let currentTodo = this.state.currentTodo;
        todos.push({
            todoText:currentTodo,
            compleated:false
        });
        this.setState({
            todos,
            currentTodo:''
        }
        );
        //this.incrementTotalTodoCount();
    }

    deleteTodo(todoToBeDeleted){
        let todos = this.state.todos;
        todos.splice(todoToBeDeleted,1);
        this.setState({
            todos
        });
        console.log("--------------"+todoToBeDeleted);
        //this.decrementTotalTodoCount();
    }

    editTodo(position,newValue){
        //console.log("--------editTodoTriggered"+position+" - "+newValue);
        let todos = this.state.todos;
        let updatedTodo = todos[position];
        updatedTodo.todoText = newValue;
        this.setState({
            todos
        })
    }

    // componentDidMount(){
    //     let todos = this.state.todos;
    //     let totalTodos = todos.length;
    //     let compleatedTodos = 0;
    //     let totalTodoVsCompleatedTodosCount={};
    //     todos.forEach(function(todo){
    //         if(todo.compleated===true){
    //             compleatedTodos++;
    //         }

    //         let totalTodoVsCompleatedTodosCount={};
    //         totalTodoVsCompleatedTodosCount.totalTodos = totalTodos;
    //         totalTodoVsCompleatedTodosCount.compleatedTodos = compleatedTodos;
    //         this.state(
    //             {
    //                 totalTodoVsCompleatedTodosCount
    //             }
    //         )
    //     })
    // }

    render() {
        // var self = this;
        //binding of this ref to local var
        //If you want to access [this] in callback function then bind it in some other var 
        //because callback function will have it's own scope
        return(
            
            <section> 
            <TodoFormComponent 
                currentTodo = {this.state.currentTodo}
                updateTodo = {this.updateTodo}
                addTodo = {this.addTodo}
                />
            <ul>
                {
                    this.state.todos.map((todo, index)=> // Callback function - this refers only it's scope
                    
                    <TodoTextComponent 
                        key={todo.todoText} 
                        todo={todo}
                        index = {index}
                        clickHandler = {this.changeTodo} 
                        deleteTodo = {this.deleteTodo}
                        editTodo = {this.editTodo}/>
                    )
                }
                
            </ul>
            </section>
        );
    }
}

TodoTextComponent.propTypes = {
    todo: PropTypes.object,
    index: PropTypes.number,
    clickHandler : PropTypes.func, 
    deleteTodo : PropTypes.func,
    editTodo : PropTypes.func
}
export default TodoListComponent;
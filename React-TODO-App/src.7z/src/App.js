import React, { Component } from 'react';
import HeaderComponent from './component/common/headerComponent';
import TodoListComponent from './component/todoListComponent'; 
import FooterComponent from './component/common/footerComponent';


class App extends Component {
  render() {
    return (
      <div id="container">
        <div id = "header">
          <HeaderComponent/>
        </div>
        <div id = "main">
          <TodoListComponent/>
        </div>
        <div id = "footer">
          <FooterComponent/>   
        </div>
      </div>
    );
  }
}

export default App;

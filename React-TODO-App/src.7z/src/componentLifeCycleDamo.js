import React from 'react';

class ComponentLifeCycle extends React.Component {

    constructor(props){
        super(props)
        console.log("-----Constructor called-----");
    }

    componentWillMount(){
        console.log("-----componentWillMount called-----");
    }
    render(){
        console.log("-----render called-----");
        return(
            <h1>Component Life Cycle Demo</h1>
            
        )    
    }
    componentDidMount(){
        console.log("-----componentDidMount called-----");
    }
}

export default ComponentLifeCycle;
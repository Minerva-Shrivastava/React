import React from 'react';
import BadgeForm from './BadgeForm';
import BadgeList from './BadgeList';

class App extends React.Component{
    
    state = {
        data : [
            {
                avatar_url : 'https://avatars3.githubusercontent.com/u/14139137?v=4',
                name : "Minerva Shrivastava",
                company : "Yash Technologies"
            },
            {
                avatar_url : 'https://avatars3.githubusercontent.com/u/14139137?v=4',
                name : "Mansi Jain",
                company : "Yash Technologies"
            }
        ]
    }

    
    addNewBadge = (badgeInfo) =>{
        this.setState(
            {
                data: this.state.data.concat(badgeInfo)
            }
        );
    }

    render(){
        return(
            <div>
                <BadgeForm onSubmit={this.addNewBadge}/>
                <BadgeList badges={this.state.data}/>
            </div>
        );
    }

}

export default App;
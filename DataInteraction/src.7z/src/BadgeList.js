import React from 'react';
import Badge from './Badge';

 const BadgeList = (props)=>{
     return(
         <div>
             {
                props.badges.map(badge=>
                    <Badge {...badge} key={badge.name}/> //Spread operator ( ES6 feature )
                )
            }
         </div>
     );
 }

export default BadgeList;
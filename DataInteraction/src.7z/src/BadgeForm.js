import React from 'react';
import Axios from 'axios';
class BadgeForm extends React.Component{
    
    state = {userName : ''}

    updateUserName = (event) =>{
        event.preventDefault();
        this.setState({userName : event.target.value
        })
    }

    handleSubmit = (event) =>{
        event.preventDefault();
        console.log(this.state.userName);

        //Fetch Api
        // fetch(`https://api.github.com/users/${this.state.userName}`)
        // .then(function(res)
        //     {
        //         console.log(res.json());            
        //     })

        //Axios Api
        Axios.get(`https://api.github.com/users/${this.state.userName}`)
        .then(res => 
            {
                this.props.onSubmit(res.data);            
            })   
    }
     
    render(){
        return(
            <div style={{margin:'2em'}}>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" 
                        placeholder="Github user..."
                        onChange={this.updateUserName} />
                    <button type="submit">Add</button>
                </form>
            </div>
        );
    }
}
export default BadgeForm;
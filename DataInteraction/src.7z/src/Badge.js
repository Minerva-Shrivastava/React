import React from 'react';
const Badge = (props) =>{
    return(
        <div className="container" style={{width:'20em', margin:'1em', border:'1px solid black'}}>
            <img src={props.avatar_url} style={{margin:'1em', width:'75px'}}/>
            <div className="userDetailSection" style={{display:'inline-block', marginLeft:10}}> 
                <div style={{fontSize:'1.2em', fontWeight:'bold', marginBottom:'2.5em'}}>{props.name}</div>    
                <div style={{fontSize:'1.2em', marginBottom:'1em'}}>{props.company}</div>    
            </div>
        </div>
    );
}

export default Badge;
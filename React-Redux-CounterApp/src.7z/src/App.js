import React, { Component } from 'react';
import Counter from './counter'; 
import { Provider } from 'react-redux';
import { createStore } from 'redux';

//Initial State
const initialState={
  count : 0
}

//Reducer parameters - state, action
//based on action state will be updated by the user
function countReducer(state = initialState,action){
  switch(action.type){
    case 'INCREMENT':
    return{
      count : state.count+1
    };
    case 'DECREMENT':
    return{
      count : state.count-1
    };
    default: 
      return state;
  }
}

//Redux store that will require the reducer
const store = createStore(countReducer);

//Provider will broadcast the store to other components
const App = ()=>{
  return(
    <Provider store={store}>
      <Counter/>
    </Provider>
  )}
export default App;

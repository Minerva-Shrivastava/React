import React from 'react'; 
import { connect } from 'react-redux';

class Counter extends React.Component{
    
    increment = ()=>{
        //create action and dispatch    
        this.props.dispatch({type:"INCREMENT"});
    }
    decrement = ()=>{
        //create action and dispatch    
        this.props.dispatch({type:"DECREMENT"});
    }

    render(){
        return(
            <div>
                <h1>
                    Counter-React-App
                </h1>
                <div>
                    <button onClick={this.increment}>+</button>
                    <span>{this.props.count}</span>
                    <button onClick={this.decrement}>-</button>
                </div>
            </div>
        )
    }
}

//This will map the broadcasted store, to the relavant props. 
function mapStateToProps(state){
    return{
        count : state.count
    }
}
//connect api will take mapStateToProps.
//in your component along with props you will get dispatch method.
//This will be used for dispatching the action
export default connect(mapStateToProps)(Counter); 